import time
import os
def screenShot(driver):
    pic_time=time.strftime('%Y%m%d%H%M',(time.localtime()))
    pic_name=os.path.dirname(os.path.abspath('.'))+'\\picture\\'+pic_time+'.png'
    driver.get_screenshot_as_file(pic_name)
