from email import encoders
from email.header import Header
from email.mime.text import MIMEText
from email.utils import parseaddr, formataddr
from email.mime.multipart import  MIMEMultipart
import unittest
import smtplib,os
import time
from utils.ReadProperties import Read
from email.mime.base import MIMEBase

# 发送HTML
# text = MIMEText('<html><body><h1>Hello</h1>' +
#     '<p>send by <a href="http://www.python.org">Python</a>...</p>' +
#     '</body></html>', 'html', 'utf-8')

from utils.HTMLTestRunner import HTMLTestRunner
#从本地获取测试报告
# f=open("E:\\RequestDemo1113\\report\\result.html",'rb')
# message=f.read()
# text=MIMEText(message,'html','utf-8')

def send_email(po):
        def _format_addr(s):
                name, addr = parseaddr(s)
                return formataddr((Header(name, 'utf-8').encode(), addr))#如果包含中文，需要通过Header对象进行编码。

        from_addr = Read().getValue('from_addr')
        password = Read().getValue('password')
        to_addr = Read().getValue('to_addr')
        smtp_server = Read().getValue('smtp_server')
        tempTo = to_addr
        # 生成邮件体
        msg = MIMEMultipart()
        msg.attach(po)
        msg['From'] = _format_addr('ff <%s>' % from_addr)
        msg['To'] = ''.join(tempTo)
        msg['To'] = _format_addr('小组人员 <%s>')
        msg['Subject'] = Header('测试邮件', 'utf-8').encode()

        server = smtplib.SMTP(smtp_server, 25)  # SMTP协议默认端口是25
        server.set_debuglevel(1)  # 打印出和SMTP服务器交互的所有信息
        server.login(from_addr, password)
        # 发送指定人邮件
        # server.sendmail(from_addr, [to_addr], msg.as_string())
        # 发送多人
        server.sendmail(from_addr, tempTo, msg.as_string())
        server.quit()
        #发送附件
        with open('D:\\RobortFrameWork\\picture\\201811251712.png', 'rb') as f:
                # 设置附件的MIME和文件名，这里是jpg类型:
                mime = MIMEBase('image', 'jpg', filename='1.jpg')
                # 加上必要的头信息:
                mime.add_header('Content-Disposition', 'attachment', filename='1.jpg')
                mime.add_header('Content-ID', '<0>')
                mime.add_header('X-Attachment-Id', '0')
                # 把附件的内容读进来:
                mime.set_payload(f.read())
                # 用Base64编码:
                encoders.encode_base64(mime)
                # 添加到MIMEMultipart:
                msg.attach(mime)

def t_send():
    # 所要执行的测试用例所在的位置
    test_dir = Read().getValue('test_dir')
    # 测试报告所在的路径
    test_report = Read().getValue('test_report')
    # 查找想要执行的文件
    discover = unittest.defaultTestLoader.discover(test_dir, pattern='*_test.py')
    # 使用HTMLTestRunner来生成testRunner，生成html测试报告
    now_time = time.strftime("%Y%m%d%H%M%S")
    file_name = test_report + '\\' + now_time + 'result.html'
    fp = open(file_name, 'wb')
    runner = HTMLTestRunner(stream=fp, title="测试报告", description="运行环境:firefox")
    runner.run(discover)
    fp.close()
    # 查找修改日期最新的测试方法
    new_report1 = new_report(test_report)
    f = open(new_report1, 'rb')
    message = f.read()
    text = MIMEText(message, 'html', 'utf-8')

    # 发送测试报告
    send_email(text)
#查找最新生成的测试报告
def new_report(files):
    lists = os.listdir(files)
    lists.sort(key=lambda fn: os.path.getmtime(files+"\\"+fn))
    file_new = os.path.join(files,lists[-1])
    print(file_new)
    return file_new