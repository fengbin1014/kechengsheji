import unittest
# 验证发邮件的测试用例
class C(unittest.TestCase):
    def test_c(self):
        print(2)