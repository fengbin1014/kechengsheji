import unittest
# 验证发邮件的测试用例，
class B(unittest.TestCase):
    def test_b(self):
        print(1)